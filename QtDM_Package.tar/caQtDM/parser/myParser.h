#include <qfile.h>
#include "XmlWriter.h"

using namespace std;

class myParser {

public:
  XmlWriter *xw;
};
