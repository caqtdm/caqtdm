#ifndef CAQTDM_H
#define CAQTDM_H
 QApplication app;
#endif // CAQTDM_H
