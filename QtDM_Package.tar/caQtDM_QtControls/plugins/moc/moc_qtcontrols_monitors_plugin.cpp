/****************************************************************************
** Meta object code from reading C++ file 'qtcontrols_monitors_plugin.h'
**
** Created: Thu Aug 22 11:03:14 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../qtcontrols_monitors_plugin.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qtcontrols_monitors_plugin.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_CustomWidgetInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_CustomWidgetInterface[] = {
    "CustomWidgetInterface\0"
};

void CustomWidgetInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData CustomWidgetInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject CustomWidgetInterface::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_CustomWidgetInterface,
      qt_meta_data_CustomWidgetInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CustomWidgetInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CustomWidgetInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CustomWidgetInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CustomWidgetInterface))
        return static_cast<void*>(const_cast< CustomWidgetInterface*>(this));
    if (!strcmp(_clname, "QDesignerCustomWidgetInterface"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< CustomWidgetInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< CustomWidgetInterface*>(this));
    return QObject::qt_metacast(_clname);
}

int CustomWidgetInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_CustomWidgetCollectionInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_CustomWidgetCollectionInterface[] = {
    "CustomWidgetCollectionInterface\0"
};

void CustomWidgetCollectionInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData CustomWidgetCollectionInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject CustomWidgetCollectionInterface::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_CustomWidgetCollectionInterface,
      qt_meta_data_CustomWidgetCollectionInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CustomWidgetCollectionInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CustomWidgetCollectionInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CustomWidgetCollectionInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CustomWidgetCollectionInterface))
        return static_cast<void*>(const_cast< CustomWidgetCollectionInterface*>(this));
    if (!strcmp(_clname, "QDesignerCustomWidgetCollectionInterface"))
        return static_cast< QDesignerCustomWidgetCollectionInterface*>(const_cast< CustomWidgetCollectionInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidgetCollection"))
        return static_cast< QDesignerCustomWidgetCollectionInterface*>(const_cast< CustomWidgetCollectionInterface*>(this));
    return QObject::qt_metacast(_clname);
}

int CustomWidgetCollectionInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_caBitnamesInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_caBitnamesInterface[] = {
    "caBitnamesInterface\0"
};

void caBitnamesInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData caBitnamesInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caBitnamesInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_caBitnamesInterface,
      qt_meta_data_caBitnamesInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caBitnamesInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caBitnamesInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caBitnamesInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caBitnamesInterface))
        return static_cast<void*>(const_cast< caBitnamesInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< caBitnamesInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int caBitnamesInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_caLedInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_caLedInterface[] = {
    "caLedInterface\0"
};

void caLedInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData caLedInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caLedInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_caLedInterface,
      qt_meta_data_caLedInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caLedInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caLedInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caLedInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caLedInterface))
        return static_cast<void*>(const_cast< caLedInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< caLedInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int caLedInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_caLinearGaugeInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_caLinearGaugeInterface[] = {
    "caLinearGaugeInterface\0"
};

void caLinearGaugeInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData caLinearGaugeInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caLinearGaugeInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_caLinearGaugeInterface,
      qt_meta_data_caLinearGaugeInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caLinearGaugeInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caLinearGaugeInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caLinearGaugeInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caLinearGaugeInterface))
        return static_cast<void*>(const_cast< caLinearGaugeInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< caLinearGaugeInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int caLinearGaugeInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_caCircularGaugeInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_caCircularGaugeInterface[] = {
    "caCircularGaugeInterface\0"
};

void caCircularGaugeInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData caCircularGaugeInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caCircularGaugeInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_caCircularGaugeInterface,
      qt_meta_data_caCircularGaugeInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caCircularGaugeInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caCircularGaugeInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caCircularGaugeInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caCircularGaugeInterface))
        return static_cast<void*>(const_cast< caCircularGaugeInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< caCircularGaugeInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int caCircularGaugeInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_caLineEditInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_caLineEditInterface[] = {
    "caLineEditInterface\0"
};

void caLineEditInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData caLineEditInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caLineEditInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_caLineEditInterface,
      qt_meta_data_caLineEditInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caLineEditInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caLineEditInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caLineEditInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caLineEditInterface))
        return static_cast<void*>(const_cast< caLineEditInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< caLineEditInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int caLineEditInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_caThermoInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_caThermoInterface[] = {
    "caThermoInterface\0"
};

void caThermoInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData caThermoInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caThermoInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_caThermoInterface,
      qt_meta_data_caThermoInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caThermoInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caThermoInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caThermoInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caThermoInterface))
        return static_cast<void*>(const_cast< caThermoInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< caThermoInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int caThermoInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_caCartesianPlotInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_caCartesianPlotInterface[] = {
    "caCartesianPlotInterface\0"
};

void caCartesianPlotInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData caCartesianPlotInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caCartesianPlotInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_caCartesianPlotInterface,
      qt_meta_data_caCartesianPlotInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caCartesianPlotInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caCartesianPlotInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caCartesianPlotInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caCartesianPlotInterface))
        return static_cast<void*>(const_cast< caCartesianPlotInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< caCartesianPlotInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int caCartesianPlotInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_caStripPlotInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_caStripPlotInterface[] = {
    "caStripPlotInterface\0"
};

void caStripPlotInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData caStripPlotInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caStripPlotInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_caStripPlotInterface,
      qt_meta_data_caStripPlotInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caStripPlotInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caStripPlotInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caStripPlotInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caStripPlotInterface))
        return static_cast<void*>(const_cast< caStripPlotInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< caStripPlotInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int caStripPlotInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_caByteInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_caByteInterface[] = {
    "caByteInterface\0"
};

void caByteInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData caByteInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caByteInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_caByteInterface,
      qt_meta_data_caByteInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caByteInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caByteInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caByteInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caByteInterface))
        return static_cast<void*>(const_cast< caByteInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< caByteInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int caByteInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_caTableInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_caTableInterface[] = {
    "caTableInterface\0"
};

void caTableInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData caTableInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caTableInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_caTableInterface,
      qt_meta_data_caTableInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caTableInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caTableInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caTableInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caTableInterface))
        return static_cast<void*>(const_cast< caTableInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< caTableInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int caTableInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_caCameraInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_caCameraInterface[] = {
    "caCameraInterface\0"
};

void caCameraInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData caCameraInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caCameraInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_caCameraInterface,
      qt_meta_data_caCameraInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caCameraInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caCameraInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caCameraInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caCameraInterface))
        return static_cast<void*>(const_cast< caCameraInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< caCameraInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int caCameraInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_caCalcInterface[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_caCalcInterface[] = {
    "caCalcInterface\0"
};

void caCalcInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData caCalcInterface::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caCalcInterface::staticMetaObject = {
    { &CustomWidgetInterface::staticMetaObject, qt_meta_stringdata_caCalcInterface,
      qt_meta_data_caCalcInterface, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caCalcInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caCalcInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caCalcInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caCalcInterface))
        return static_cast<void*>(const_cast< caCalcInterface*>(this));
    if (!strcmp(_clname, "com.trolltech.Qt.Designer.CustomWidget"))
        return static_cast< QDesignerCustomWidgetInterface*>(const_cast< caCalcInterface*>(this));
    return CustomWidgetInterface::qt_metacast(_clname);
}

int caCalcInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CustomWidgetInterface::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_END_MOC_NAMESPACE
