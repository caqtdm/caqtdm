/****************************************************************************
** Meta object code from reading C++ file 'doubletabwidget.h'
**
** Created: Thu Mar 28 14:42:13 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/doubletabwidget.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'doubletabwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_caDoubleTabWidget[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       2,   24, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      21,   19,   18,   18, 0x08,
      35,   33,   18,   18, 0x08,

 // properties: name, type, flags
      55,   47, 0x0a095003,
      71,   47, 0x0a095003,

       0        // eod
};

static const char qt_meta_stringdata_caDoubleTabWidget[] = {
    "caDoubleTabWidget\0\0r\0setRow(int)\0c\0"
    "setCol(int)\0QString\0itemsHorizontal\0"
    "itemsVertical\0"
};

void caDoubleTabWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        caDoubleTabWidget *_t = static_cast<caDoubleTabWidget *>(_o);
        switch (_id) {
        case 0: _t->setRow((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->setCol((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData caDoubleTabWidget::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject caDoubleTabWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_caDoubleTabWidget,
      qt_meta_data_caDoubleTabWidget, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &caDoubleTabWidget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *caDoubleTabWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *caDoubleTabWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_caDoubleTabWidget))
        return static_cast<void*>(const_cast< caDoubleTabWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int caDoubleTabWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = getItemsHor(); break;
        case 1: *reinterpret_cast< QString*>(_v) = getItemsVer(); break;
        }
        _id -= 2;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setItemsHor(*reinterpret_cast< QString*>(_v)); break;
        case 1: setItemsVer(*reinterpret_cast< QString*>(_v)); break;
        }
        _id -= 2;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
