#ifndef ECOSTANTS_H
#define ECOSTANTS_H

#define MARGIN 0.1
#define MIN_MARGIN 1
#define MIN_SIZE 9
#define MIN_BUTTON_SIZE 54

#endif
